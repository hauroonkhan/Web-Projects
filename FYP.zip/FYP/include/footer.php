<!-- ======= Footer ======= -->
<footer id="footer">

<div class="container footer-content"><br>
                <h3 class="me-md-auto text-center text-md-start">NTU Developers</h3><br>
                <p class="me-md-auto text-center text-md-start">We are a team currently persuing bachelor of Software Engineering in National Textile University Faisalabad.</p>
                
            </div>

<div class="container d-md-flex py-4">

  <div class="me-md-auto text-center text-md-start">
    <div class="copyright">
      &copy; Copyright <strong><span>PriceHub</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
     
      Designed by <a href="https://haroon-horikhan.w3spaces.com">Softiano</a>
    </div>
  </div>
  <div class="social-links text-center text-md-end pt-3 pt-lg-0 ">
    <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
    <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
    <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
    <a href="#" class="google-plus"><i class="bi bi-github"></i></a>
    <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
  </div>
</div>
<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="bi bi-arrow-up"></i></button>
</footer><!-- End Footer -->

<script src="js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>