<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/headfoot.css">
    <link rel="stylesheet" href="styl.css">
    <link rel="stylesheet" href="css/style.css">
   
</head>

<body>
    <header>

        <nav class="navbar navbar-expand-lg navbar-dark  headerNav">
            <div class="container">
                <a class="navbar-brand" href="#">
                  <h1>PriceHub</h1>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon togle"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item ">
                            <a class="nav-link active " style="color: red;" href="#">Home </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Prducts</a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link "  href="#">Register Store</a>
                        </li>
						<li class="nav-item">
                            <a class="nav-link "  href="compare.php">Compare Products</a>
                        </li>
                    </ul>

                    <form action="compare.php" method="post" class="form-inline my-2 my-lg-0 searchForm">
                        <input class="form-control mr-sm-2 col-8" name="val" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-danger my-2 my-sm-0" type="submit" name="submit"><i class="bi bi-search"></i></button>
                    </form>
     
                    <div class="rightSide">
                        <div class="dropdown">
                            <a id ="fa" data-toggle="dropdown">
                                <?php
                                if (session_status() == PHP_SESSION_NONE) {
                                    session_start();
                                }
                                if (isset($_SESSION["email"])) { ?>
                                    Hello <?php echo $_SESSION["email"]; ?>
                                <?php  } else { ?>
                                    <i class="fa fa-user"></i>
                                <?php  } ?>
                            </a>
                            <div class="dropdown-menu">
                                <?php
                                if (isset($_SESSION["email"])) { ?>
                                    <a class="dropdown-item" href="" class="">My Profile</a>
                                    <a class="dropdown-item" href="logout-user.php" class="user_logout">Logout</a>
                                <?php  } else { ?>
                                    <a class="dropdown-item"  href="Loginform/login-user.php">Login</a>
                                    <a class="dropdown-item" href="Loginform/signup-user.php">Register</a>
                                <?php  } ?>

                            </div>
                            <a id ="fa" href="Loginform/home.php"><i class="fa fa-heart"></i>
                            
                        </a>
                       
                        </div>
                    </div>
                   

                </div>
            </div>
        </nav>

    </header>