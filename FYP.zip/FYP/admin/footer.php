                        <!-- Footer Start-->
                        <div id="admin-footer">
                          
                                <span> Created By Softiano</span>
                            
                        </div>
                        <!-- Footer End-->
                    </div>
                    <!-- Content End-->
                </div>
            </div>
        </div>
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/admin_actions.js" type="text/javascript"></script>
        <script src="js/jquery-te-1.4.0.min.js" type="text/javascript"></script>   
        <!-- https://jqueryte.com/ -->
        <script>
            $('.product_description').jqte({
                link: false,
                unlink: false,
                color: false,
                source: false,
            });
        </script>
    </body>
</html>
