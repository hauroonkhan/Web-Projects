<?php
  include 'admin/php_files/database.php';

  $hostname = "http://localhost:8090/fyp";
    
?>