<?php
 $db_host = "localhost"; 
		 $db_user = "root";      
		$db_pass = "";   
		 $db_name = "fyp"; 
		
		$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);

$user_id=$_GET['id'];



$query=mysqli_query($con,"DELETE FROM `fav` WHERE `id`='$user_id'")or dir(mysqli_error($con));

if(!$query){
	echo"<script>
window.close();
</script>";
}else{
	echo"<script>
window.close();
</script>";
}

?>