<?php

session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'fyp');

if (isset($_POST['submit'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];

  if (empty($username)) {
  	array_push($errors, "Email is required");
  }
  

  	//$password = md5($password);
  	$query = "SELECT * FROM user WHERE email='$email' ";
  	$results = mysqli_query($db, $query)or die(mysqli_error($db));
	while($row=mysqli_fetch_array($results)){
		$fname=$row['name'];
	}
	
  	
  	echo   $_SESSION['f_name'] = $fname;
  	 echo  $_SESSION['success'] = "You are now logged in";
  	  header('location: index.php');
  
}

?>
