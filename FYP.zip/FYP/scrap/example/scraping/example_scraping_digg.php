<?php
include_once('../../simple_html_dom.php');

function scraping_digg() {
    // create HTML DOM
    $html = file_get_html('https://www.daraz.pk/catalog/?q=vivo+y11&_keyori=ss&from=input&spm=a2a0e.searchlistcategory.search.go.33fa4b5313FWAH');

    // get news block
    foreach($html->find('div.gridItem--Yd0sa') as $article) {
        // get title
        $item['title'] = trim($article->find('a', 0)->plaintext);
        // get details
        $item['details'] = trim($article->find('img', 0)->plaintext);
        // get intro
        

        $ret[] = $item;
    }
    
    // clean up memory
    $html->clear();
    unset($html);

    return $ret;
}


// -----------------------------------------------------------------------------
// test it!

// "http://digg.com" will check user_agent header...
ini_set('user_agent', 'My-Application/2.5');

$ret = scraping_digg();

foreach($ret as $v) {
    echo $v['title'].'<br>';
    echo '<ul>';
    echo '<li>'.$v['details'].'</li>';
   
    echo '</ul>';
}

?>