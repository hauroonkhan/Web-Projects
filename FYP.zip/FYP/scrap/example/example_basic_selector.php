<?php
// example of how to use basic selector to retrieve HTML contents
include('../simple_html_dom.php');
 
// get DOM from URL or file
$html = file_get_html('https://www.mega.pk/mobiles-samsung/');



// find all image with full tag
foreach($html->find('div.product-grid-div') as $e)
    echo $e->outertext . '<br>';



    

?>