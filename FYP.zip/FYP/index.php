<?php
include 'include/header.php';
?>

<div id="carouselExampleInterval" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active" data-interval="10000">
      <img src="images/img2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-interval="2000">
      <img src="images/slide1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/slide2.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-target="#carouselExampleInterval" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselExampleInterval" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </button>
</div>
  <br>
  <h1  style="text-align: center;">Registered Store</h1><br>
  <div class="card-group">
  <div class="card">
    <img src="images/mega1.jpg" class="card-img-top" alt="...">
   
  </div>
  <div class="card">
    <img src="images/ebay.png" class="card-img-top" alt="...">
   
  </div>
  <div class="card">
    <img src="images/flipkart.png" class="card-img-top" alt="...">
    
  </div>
  <div class="card">
    <img src="images/amazon.jpg" class="card-img-top" alt="...">
   
  </div>
</div>
  <br>
  <h1  style="text-align: center;">Popular Products </h1>
  <hr>
<br><br>

   
<div class="container">
   
    <div class="row">
        <?php

$curl = curl_init();

curl_setopt_array($curl, [
	CURLOPT_URL => "https://amazon24.p.rapidapi.com/api/todaydeals",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
	CURLOPT_HTTPHEADER => [
		"X-RapidAPI-Host: amazon24.p.rapidapi.com",
		"X-RapidAPI-Key: cbee658032msh79663b658dc6f04p170908jsna0dbbf3cc798"
	],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
	echo "cURL Error #:" . $err;
} else {
	//echo $response;
	$array = json_decode($response, true);
	$a=0;
for($i=0;$i<6;$i++){
	if($array['deal_docs'][$a]['deal_title']!='Save on Fitness Essentials from Our Brands' AND $array['deal_docs'][$a]['deal_main_image_url']!='https://m.media-amazon.com/images/I/314qRPsAMgL.jpg' ){
?>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid2">
                <div class="product-image2">
                    <a href="<?php echo $array['deal_docs'][$a]['deal_details_url']; ?>">
                 
                        <img class="pic-2" src="<?php echo $array['deal_docs'][$a]['deal_main_image_url']; ?>">
                    </a>
                    <ul class="social">
                        <li><a href="#" data-tip="Quick View"><i class="fa fa-eye"></i></a></li>
                        <li><a href="#" data-tip="Add to Favoritlist"><i class="fa fa-heart"></i></a></li>
                        <li><a href="#" data-tip="Compare"><i class="fa fa-balance-scale"></i></a></li>
                    </ul>
                    <a class="add-to-cart" href="">Order Now</a>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo $array['deal_docs'][$a]['deal_title']; ?></a></h3>
                    <span class="price">$<?php echo $array['deal_docs'][$a]['app_sale_range']['min']; ?>-$<?php echo $array['deal_docs'][$a]['app_sale_range']['max']; ?></span>
                </div>
            </div>
        </div>
		<?php
		$a++;
		echo "<br>";
	}
		}
		
		?>
		<hr>
	
		 <hr>
<br><br>
		<?php
		
		
		for($i=7;$i<14;$i++){
	if($array['deal_docs'][$a]['deal_title']!='Save on Fitness Essentials from Our Brands' AND $array['deal_docs'][$a]['deal_main_image_url']!='https://m.media-amazon.com/images/I/314qRPsAMgL.jpg' ){
?>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid2">
                <div class="product-image2">
                    <a href="<?php echo $array['deal_docs'][$a]['deal_details_url']; ?>">
                 
                        <img class="pic-2" src="<?php echo $array['deal_docs'][$a]['deal_main_image_url']; ?>">
                    </a>
                    <ul class="social">
                        <li><a href="#" data-tip="Quick View"><i class="fa fa-eye"></i></a></li>
                        <li><a href="#" data-tip="Add to Favoritlist"><i class="fa fa-heart"></i></a></li>
                        <li><a href="#" data-tip="Compare"><i class="fa fa-balance-scale"></i></a></li>
                    </ul>
                    <a class="add-to-cart" href="">Order Now</a>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo $array['deal_docs'][$a]['deal_title']; ?></a></h3>
                    <span class="price">$<?php echo $array['deal_docs'][$a]['app_sale_range']['min']; ?>-<s>$<?php echo $array['deal_docs'][$a]['app_sale_range']['max']; ?></s></span>
                </div>
            </div>
        </div>
		<?php
		$a++;
		echo "<br>";
	}
		}
		?>
		<hr>
	
		 <hr>
		<br><br>
		<?php
		
		
		for($i=15;$i<22;$i++){
	if($array['deal_docs'][$a]['deal_title']!='Save on Fitness Essentials from Our Brands' AND $array['deal_docs'][$a]['deal_main_image_url']!='https://m.media-amazon.com/images/I/314qRPsAMgL.jpg' ){
?>
        <div class="col-md-3 col-sm-6">
            <div class="product-grid2">
                <div class="product-image2">
                    <a href="<?php echo $array['deal_docs'][$a]['deal_details_url']; ?>">
                 
                        <img class="pic-2" src="<?php echo $array['deal_docs'][$a]['deal_main_image_url']; ?>">
                    </a>
                    <ul class="social">
                        <li><a href="#" data-tip="Quick View"><i class="fa fa-eye"></i></a></li>
                        <li><a href="#" data-tip="Add to Favoritlist"><i class="fa fa-heart"></i></a></li>
                        <li><a href="#" data-tip="Compare"><i class="fa fa-balance-scale"></i></a></li>
                    </ul>
                    <a class="add-to-cart" href="">Order Now</a>
                </div>
                <div class="product-content">
                    <h3 class="title"><a href="#"><?php echo $array['deal_docs'][$a]['deal_title']; ?></a></h3>
                    <span class="price">$<?php echo $array['deal_docs'][$a]['app_sale_range']['min']; ?>-<s>$<?php echo $array['deal_docs'][$a]['app_sale_range']['max']; ?></s></span>
                </div>
            </div>
        </div>
		<?php
		$a++;
		echo "<br>";
	}
		}
		
		
		
}

		?>	
		
		
    </div>
</div>
<br>


		
   




  <?php
include 'include/footer.php';
?>