<?php
//include 'server.php';
include 'include/header.php';
//session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'fyp');

if (isset($_POST['submit'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];

  if (empty($username)) {
  	array_push($errors, "Email is required");
  }
  

  if (count($errors) == 0) {
  	$password = md5($password);
  	$query = "SELECT * FROM user WHERE email='$email' ";
  	$results = mysqli_query($db, $query);
	while($row=mysqli_fetch_array($results)){
		$fname=$row['name'];
	}
	
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['f_name'] = $fname;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: index.php');
  	}else {
  		array_push($errors, "Wrong username / password ");
  	}
  }
}

?>

<div class="body">
  <div class="wrapper">
    
    <h2>Login</h2>
    <form action="process.php" method="post" >
    <?php //include('error.php'); ?>
   
      <div class="input-box">
        <input type="email" placeholder="Enter your email" required name="email">
      </div>
     
      <div class="input-box">
        <input type="password" placeholder=" password" required name="password">
      </div>
      
      <div class="input-box button">
        <input type="Submit" value="Login" name="submit">
      </div>
      <div class="text">
        <h3>Don't Have Account <a href="register.php">SignUp Now</a></h3>
      </div>
      <div class="text">
        <h3> <a href="forgot.php">Forgot Password</a></h3>
      </div>
     
    </form>
  </div>
  </div>
  <?php

include 'include/footer.php';
?>