
<?php
include'include/header.php';
?>
  <div class="body">
  <div class="wrapper">
 
    <h2>Reset Password</h2>
    <form action="forgot.php" method="post" >
   
      <div class="input-box">
        <input type="email" placeholder="Enter your email" required name="email">
      </div>
     
      <div class="input-box">
        <input type="password" placeholder="new password" required name="password">
      </div>
     
      
      <div class="input-box button">
        <input type="Submit" value="Reset" name="submit">
      </div>
      <div class="text">
        <h3>Go to Login Page <a href="login.php">Login now</a></h3>
      </div>
     
    </form>
  </div>
  </div>
  <?php
include'include/footer.php';
?>