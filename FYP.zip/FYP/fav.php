<?php
 $db_host = "localhost"; 
		 $db_user = "root";      
		$db_pass = "";   
		 $db_name = "fyp"; 
		
		$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);

$user_id=$_GET['user'];

$link=$_GET['link'];
$img=$_GET['img'];

$query=mysqli_query($con,"INSERT INTO `fav`(`user_id`, `link`,`img`) VALUES ('$user_id','$link','$img')");

if(!$query){
	echo"<script>
window.close();
</script>";
}else{
	echo"<script>
window.close();
</script>";
}

?>